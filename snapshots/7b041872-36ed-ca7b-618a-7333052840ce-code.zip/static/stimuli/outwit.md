A son said to his father one day: "I will hide, and you will not be able to find me". The father replied: "Hide wherever you like", and he went into his house to rest.

The son saw a three-kernel peanut, and changed himself into one of the kernels; a fowl coming along picked up the peanut and swallowed it; and a wild bush-cat caught and ate the fowl; and a dog met and caught and ate the bush-cat. After a little time the dog was swallowed by a python, that, having eaten its meal, went to the river and was snared in a fish-trap.

The father searched for the his son and, not seeing him, went to look at the fish-trap. On pulling it to the river-side he found a large python in it. He opened it, and saw a dog inside, in which he found a bush-cat, and on opening that he dicovered a fowl, from which he took the peanut, and breaking the shell, he then revealed his son. The son was so dumbfounded that he never again tried to outwit his father.
